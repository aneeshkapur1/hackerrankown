package com.hackerrank.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hackerrank.dao.HackerRankRegisterDao;
import com.hackerrank.exceptions.HackerRankException;
import com.hackerrank.model.HackerRankRegister;
import com.hackerrank.model.encrypt;
import com.hackerrank.util.ConnectionUtil;


/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("user1");
		String target = request.getParameter("pass1");
		encrypt td= null;
		
       
		String email = request.getParameter("email");
		Connection connObj = null;
		String page = "";
			

		try{
				td = new encrypt();
		
			 	String encrypted=td.encryptpass(target);
		        

		        System.out.println("String To Encrypt: "+ target);
		        System.out.println("Encrypted String:" + encrypted);
		     
			connObj = ConnectionUtil.getConnection();
			connObj.setAutoCommit(false);
		HackerRankRegister hackerRankRegister = new HackerRankRegister(username,encrypted,email);
		HackerRankRegisterDao hackerDao = new HackerRankRegisterDao(); 
		int userId = hackerDao.registerUser(connObj, hackerRankRegister);
		hackerRankRegister.setUserId(userId);
		
		
		if(userId != 0)
		{
			System.out.println("Your EMployee Id is" + userId);
			System.out.println("Please Remember for future");
			request.setAttribute("registeruser",hackerRankRegister);
			page = "Register.jsp";
			
		}
		else
		{
			request.setAttribute("error", "error registering try again");
			page = "HackerRank.jsp";
		}
		
		RequestDispatcher rd =  request.getRequestDispatcher(page);
		rd.forward(request,response);
		
		connObj.commit();
		}catch(SQLException s)
		{
			try {
				connObj.rollback();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			s.printStackTrace();
		} catch (HackerRankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			request.setAttribute("error", "error registering try again");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		finally
		{
			try
			{
				if(connObj != null)
				{
					connObj.close();
				}
				
			}catch(SQLException s)
			{
				s.printStackTrace();
			}
		}
		
	}

}
