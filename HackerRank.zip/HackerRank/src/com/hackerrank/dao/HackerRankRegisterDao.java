package com.hackerrank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.hackerrank.exceptions.HackerRankException;
import com.hackerrank.model.HackerRankRegister;


public class HackerRankRegisterDao {

	public HackerRankRegisterDao() {
		// TODO Auto-generated constructor stub
	}
	
	public int registerUser(Connection connObj, HackerRankRegister user) throws SQLException, HackerRankException
	{
		
		
		//employee
		String query = "Insert into details(username,password,email) values(?,?,?)";
		PreparedStatement pstmt = null;
		ResultSet result = null;
		int count = 0;
		int generatedId = 0;
		
		try{
			
		
			pstmt = connObj.prepareStatement(query);
			pstmt.setString(1,user.getUsername());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3,user.getEmail() );
			
			
			count = pstmt.executeUpdate();
				result = pstmt.getGeneratedKeys();
			if(result.next())
			{
				generatedId = result.getInt(1);
			}
		}
//	
		catch(SQLException s)
		{
		
		s.printStackTrace();
		throw new HackerRankException("connection or query problem" + s);
	}
	catch(Exception o)
	{
		System.out.println("Exception");
		throw new HackerRankException("connection or query problem" + o);
		
	}finally
	{
		
		if(pstmt != null)
		{
			try
			{
				pstmt.close();
				
			}
			catch(SQLException o)
			{
				o.printStackTrace();
				throw new HackerRankException("connection or query problem" + o);
			}
		}
		
	}
	
return generatedId;
}
	

}
