package com.hackerrank.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionUtil {
	
	

public static Connection getConnection() throws SQLException
{
	Connection connObj = null;
	
		DriverManager.registerDriver(new com.mysql.jdbc.Driver());
		
				connObj = DriverManager.getConnection("jdbc:mysql://localhost/hackerrank","root","root");
		if(connObj == null)
		{
			System.out.println("No connection");
		}
		else
		{
			System.out.println("Connection Found");
		}
		
		
	
	return connObj;

}
}
