package com.hackerrankspring.controller;

public class TestController {

	public TestController() {
		// TODO Auto-generated constructor stub
	}

	
}
