package com.hackerrankspring.service;

import java.sql.Connection;
import java.sql.SQLException;

import com.hackerrankspring.dao.HackerRankRegisterDao;
import com.hackerrankspring.exceptions.HackerRankException;
import com.hackerrankspring.model.HackerRankRegister;

public class HackerRankRegisterService implements IHackerRankRegister{

	HackerRankRegisterDao hackerRankRegisterDao = new HackerRankRegisterDao();
	public HackerRankRegisterService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int registerUser(Connection connObj, HackerRankRegister user) throws SQLException, HackerRankException {
		// TODO Auto-generated method stub
		return hackerRankRegisterDao.registerUser(connObj,user);
	}

}
