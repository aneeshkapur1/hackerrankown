package com.hackerrankspring.service;

import java.sql.Connection;
import java.sql.SQLException;

import com.hackerrankspring.exceptions.HackerRankException;
import com.hackerrankspring.model.HackerRankRegister;



public interface IHackerRankRegister {
	
	public int registerUser(Connection connObj, HackerRankRegister user) throws SQLException, HackerRankException;

}
