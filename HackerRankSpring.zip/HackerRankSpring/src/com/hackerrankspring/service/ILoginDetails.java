package com.hackerrankspring.service;

import com.hackerrankspring.exceptions.HackerRankException;
import com.hackerrankspring.model.LoginDetails;

public interface ILoginDetails {

	public boolean loginCheck(LoginDetails loginDetails) throws HackerRankException ;
}
