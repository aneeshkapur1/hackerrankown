package com.hackerrankspring.service;

import com.hackerrankspring.dao.LoginDAO;
import com.hackerrankspring.exceptions.HackerRankException;
import com.hackerrankspring.model.LoginDetails;


public class LoginDetailsService implements ILoginDetails {

	LoginDAO loginDAO = new LoginDAO();
	public LoginDetailsService() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public boolean loginCheck(LoginDetails loginDetails) throws HackerRankException {
		// TODO Auto-generated method stub
		return loginDAO.loginCheck(loginDetails);
	}
	
	
}
